package com.qianfeng.customerui;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerUiApplicationTests {

    @Test
    void contextLoads() {
    }

}
