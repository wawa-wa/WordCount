package com.qianfeng.goodsui;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoodsUiApplicationTests {

    @Test
    void contextLoads() {
    }

}
