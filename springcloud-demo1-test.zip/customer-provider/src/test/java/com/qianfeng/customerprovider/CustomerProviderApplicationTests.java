package com.qianfeng.customerprovider;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerProviderApplicationTests {

    @Test
    void contextLoads() {
    }

}
